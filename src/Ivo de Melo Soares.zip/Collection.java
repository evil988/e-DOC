import java.util.ArrayList;

public class Collection {
	
	private ArrayList<Doc> docs = new ArrayList<Doc>();
	private ArrayList<Pat> pats = new ArrayList<Pat>();

}
