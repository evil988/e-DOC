
public class Main {	

	public static void main(String[] args) {		
		
		Collection database = new Collection();
		
		new MainWindow();
		
	}
}
